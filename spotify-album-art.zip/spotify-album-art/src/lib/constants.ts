export enum BROADCAST_CHANNEL {
  RELOAD = "reload",
}
